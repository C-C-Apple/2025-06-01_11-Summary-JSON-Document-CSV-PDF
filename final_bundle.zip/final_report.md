# KABUKI-INV — Final Consolidation (Phase 1–4)

- Generated (UTC+7): 2025-09-14T08:20:34+0700
- Devices: iP11Pro, iP12mini-1, iP12mini-2, iPad, iP15P-Ghost, iP12-Ghost

## Facts
- Date scope: 2025-06-09 (UTC+7)
- Baseband disconnects (iP12mini-1): 09:40:50 / 22:28:33 / 23:50:15
- Apple Support contacts (iP12-Ghost): 13:42 / 13:44
- No same-second/minute match; same-day sequence confirmed.

## Hypotheses (explicitly labeled)
- Targeted interference linked to VN-Telco (hypothesis only; not proven).

## Artifacts
